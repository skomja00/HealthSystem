/*
This class will be good for web user update - provides a single web user plus the list of user Roles (for pick list).
 */
package model.patientVisit;

public class PatientVisitWithUser {
    
    public StringData webUserSD = new StringData();
    public model.user.StringDataList webUserSDL = new model.user.StringDataList();
    
}