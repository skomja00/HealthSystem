function cars(id) {

    // ` this is a "back tick". Use it to define multi-line strings in JavaScript.
    var content = `  
      <p>
        Car Content COMING SOON !
      </p>
    `;
    document.getElementById(id).innerHTML = content;
}