function users(id) {

    // ` this is a "back tick". Use it to define multi-line strings in JavaScript.
    var content = `  
      <p>
        User Content COMING SOON !
      </p>
    `;
    document.getElementById(id).innerHTML = content;
}