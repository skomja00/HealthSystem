function ComingSoon ( {message, feature} ) {
    return (
        <div>
            <h3>
                {feature}
            </h3>

            <p>
                {message}
            </p>
        </div>
    );
}