function Home() {
    return (
        <div>
            <h3>
                Home is Where the Heart Is
            </h3>

            <p>
                Lame, I know. Couldn't think of anything else to use as Home Content for this example.
            </p>
        </div>
    );
}