function VisitList() {
    return (
        <div>
            <h3>
                Patient Visit List
            </h3>

            <p>
                Coming Soon!
            </p>
        </div>
    );
}