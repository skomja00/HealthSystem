/**
 * Login content 
 */
function login(targetId) {

    var content =   
        "<p>"+
        "   Enter your user name and password to login."+
        "</p>";
    document.getElementById(targetId).innerHTML = content;
}