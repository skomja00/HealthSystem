/**
 * Profile content 
 */
function profile(targetId) {

    var content =   
        "<p>"+
        "   Enter your profile settings."+
        "</p>";
    document.getElementById(targetId).innerHTML = content;
}