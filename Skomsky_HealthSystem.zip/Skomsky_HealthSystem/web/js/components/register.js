/**
 * Register content 
 */
function register(targetId) {

    var content =   
        "<p>"+
        "   Please register."+
        "</p>";
    document.getElementById(targetId).innerHTML = content;
}