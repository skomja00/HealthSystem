/**
 * Services content 
 */
function services(targetId) {
    var content =   
        "<p>" +
        "   Services Home" +
        "</p><p>" +
        "    Schedule appointments, enter charges, and gather " +
        "    patient demographics. " +
        "</p>";
    document.getElementById(targetId).innerHTML = content;
}