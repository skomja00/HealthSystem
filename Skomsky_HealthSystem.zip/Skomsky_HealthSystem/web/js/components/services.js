/**
 * Services content 
 */
function services(targetId) {
    var content =   
        "<p>" +
        "   Enter services." +
        "</p>";
    document.getElementById(targetId).innerHTML = content;
}